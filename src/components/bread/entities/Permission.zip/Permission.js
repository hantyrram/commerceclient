class Entity{
 constructor(object){
  if(typeof object !== 'object') throw new Error(`@Entity : ${object} is not of type object `);
  Object.assign(this,object);
 }

 async save(){
  if(!this._id){
   return await axios.post(this.paths('add'),this);
  }
  return await axios.post(this.paths('edit'),this);
 }

 async remove(){
  return await axios.delete(this.paths('del'));
 }

 get API_VERSION(){
  return 'apiv1';
 }

}




const paths = {
 browse : '/permissions',
 read : '/permissions/:name',
 edit : '/permissions/:name/edit',
 add : '/permissions/:name/add',
 del : '/permissions/:name/delete'
}

class Permission extends Entity{
 constructor(object){
  super(object);
 }
 get paths(){
  return (name)=>{
   return paths[name];
  }
 }
}

